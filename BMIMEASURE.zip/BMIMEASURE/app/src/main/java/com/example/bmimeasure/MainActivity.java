package com.example.bmimeasure;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myButtonListenerMethod();
    }
    public void myButtonListenerMethod(){
        Button button = (Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText heightText = (EditText)findViewById(R.id.heightInput);
                String heightStr = heightText.getText().toString();
                double height = Double.parseDouble(heightStr);
                final EditText WeightText = (EditText)findViewById(R.id.weightInput);
                String WeightStr = WeightText.getText().toString();
                double weight = Double.parseDouble(WeightStr);
                double BMI =(weight)/(height*height);
                final EditText BMIResult = (EditText)findViewById(R.id.BMIResult);
                BMIResult.setText(Double.toString(BMI));
                String BMI_Cat;
                if (BMI<15)
                    BMI_Cat = "very severely underweight";
                else if (BMI<16)
                    BMI_Cat = "severyly underweight";
                else if (BMI<18.5)
                    BMI_Cat = "underweight";
                else if (BMI<25)
                    BMI_Cat = "Normal";
                else if (BMI<35)
                    BMI_Cat = "obese class 1- Moderately obese";
                else if (BMI<40)
                    BMI_Cat = "obese class 2 -severly obese";
                else
                    BMI_Cat="obese class 3 - Very severy obese";

                final TextView BMICategory = (TextView)findViewById(R.id.BMICategory);
                BMICategory.setText(BMI_Cat);
            }
        });
    }
}
